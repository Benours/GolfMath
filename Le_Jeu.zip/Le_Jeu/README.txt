###############################################
#    										  #
#              GOLF MATHEMATIQUE              #
#											  #
###############################################


POUR LANCER LE JEU :

- Il faut executer le fichier test3.sh (c'est un
	excutable linux et non windows)



					Ce jeu est réalisé 
					pour le projet HLIN 405 :

						ETUDIANTS :
							- Mike GERMAIN
							- Benjamin BASKA
							- Kevin LASTRA

						REFERENTE :
							- Annie CHATEAU